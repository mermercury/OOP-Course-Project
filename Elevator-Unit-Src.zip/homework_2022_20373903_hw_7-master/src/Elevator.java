
public interface Elevator {
    public RequestQueue getWaitList();

    public RequestQueue getEleList();
}
